
import './App.css';
// import Dashboard from "./component/admindash"
import Header from './component/Header';

function App() {
  return (
    <div className="App">
    
      <Header/>
     
    </div>
  );
}

export default App;
