import React, { useState, useEffect } from 'react'
import logo from '../image/staff1.png'
import Axios from "axios";
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import { useNavigate } from 'react-router-dom';
import './style.css'
toast.configure();

const ChangePassword = () => {


    const navigate = useNavigate();
    const [username, setusername] = useState('')
    const [password, setpassword] = useState('')
    const [confirmpassword, setconfirmpassword] = useState('')
    const [error, seterror] = useState('')


    const changepass = (e) => {
        e.preventDefault();
        if (confirmpassword !== password) {
            seterror("Password and confirmpassword must be same!")
        }
        else {
            Axios.put(`http://localhost:8000/updatestaffpassword/`, { username, password })
                .then((res) => {
                    if (res.status === 200) {
                        toast.success("Change Successfully..", { autoClose: 1000 }
                            , {
                                position: "top-center",
                            })
                        localStorage.clear();
                        navigate('/');
                        window.location.reload();

                    }
                })
        }

    }


    return (
        <div className='change'>
            <div className="wrapper fadeInDown">
                <div className="formContent">
                    <h3>Change Your Password</h3>
                    <form method='POST'>
                        <div className="fadeIn first">
                            <img src={logo} id="icon" alt="User Icon" />
                        </div>
                        <input type="text" id="login" className="fadeIn second" name="newusername" placeholder="User Name" value={username} onChange={(e) => setusername(e.target.value)} />
                        <input type="password" id="newpassword" className="fadeIn third" name="pwd" placeholder="Enter New password" value={password} onChange={(e) => setpassword(e.target.value)} />
                        <input type="password" id="confirmpassword" className="fadeIn third" name="confirmpassword" placeholder="confirmpassword" value={confirmpassword} onChange={(e) => setconfirmpassword(e.target.value)} />
                        <span style={{ color: "red", fontSize: "17px" }}>{error}</span>
                        <input type="submit" className="fadeIn fourth" value="Change Password" onClick={changepass} />
                    </form>
                </div>
            </div>
        </div>
    )
}

export default ChangePassword