import React from 'react'
import './teamstyle.css'
// import zeel from '../image/zeel.jpg'

const OurTeam = () => {
    return (
        <div>
            <div className="tmain">
                <div className="container teammain">
                    <div className="section-title">
                        <h1 className='th1'>Meet Our Team</h1>
                    </div>

                    <div className="row">


                        <div className="column teamcolumn">
                            <div className="team">
                                <div className="team-img">
                                    <img src="" alt="Team Image"/>
                                </div>
                                <div className="team-content">
                                    <h2 className='th2'>Khushali</h2>
                                    <h3 className='th3'>Developer</h3>
                                    <p className='tp'>Some text goes here that describes about team members</p>
                                    <h4 className='th4'>khushi2806@gmail.com</h4>
                                </div>
                            </div>
                        </div>

                        <div className="column">
                            <div className="team">
                                <div className="team-img">
                                    <img src="" alt="Team Image"/>
                                </div>
                                <div className="team-content">
                                    <h2 className='th2'>Nikita</h2>
                                    <h3 className='th3'>Developer</h3>
                                    <p className='tp'>Some text goes here that describes about team members</p>
                                    <h4 className='th4'>nikitasurani16@gmail.com</h4>
                                </div>
                            </div>
                        </div>

                        <div className="column">
                            <div className="team">
                                <div className="team-img">
                                    <img src="" alt="Team Image"/>
                                </div>
                                <div className="team-content">
                                    <h2 className='th2'>Zeel</h2>
                                    <h3 className='th3'>Developer</h3>
                                    <p className='tp'>Some text goes here that describes about team members</p>
                                    <h4 className='th4'>zeelvashi02@gmail.com</h4>
                                </div>
                            </div>
                        </div>

                    </div>

                </div>
            </div>
        </div>
    )
}

export default OurTeam