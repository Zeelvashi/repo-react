import React, { useState, useEffect } from 'react';
import { NavLink } from 'react-router-dom';
import '../Admin/trackparcelcss.css';
import Axios from "axios";
import moment from 'moment';
import './Trackcss.css';
import { NavDropdown } from 'react-bootstrap';
import { useNavigate } from 'react-router-dom';
import { getToken } from '../services/getToken';
import mainlogo1 from '../image/mainlogo.png'


const Usertrackparcel = () => {
    const [Data, SetData] = useState([]);
    const [show, Setshow] = useState("");
    const [ref, Setref] = useState([]);
    const [dataresult, setdataresult] = useState('');
    const [confirmcap, setconfirmcap] = useState('');
    const [isActive, setActive] = useState(false);
    const navigate = useNavigate();
    const [username, setusername] = useState();
    const [caperror, setcaperror] = useState();
    const [captcha, setcaptcha] = useState("");
    const [parcel, setparcel] = useState({
        parceldata: "",
        destinationdata: "",
        staffparceldata: ""
    });
    const [parcelstatus, setparcelstatus] = useState("");

    var result = " ";
    useEffect(() => {

        const randomChars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz123456789"
        for (var i = 0; i < 6; i++) {
            result += randomChars.charAt(Math.floor(Math.random() * randomChars.length));
        }
        console.log('result', result)
        setdataresult(result.trim());


    }, [])
    const setcap = () => {
        setcaptcha("captcha");
    }

    const handlesearch = (e) => {
        e.preventDefault();
        console.log('dataresult',dataresult);
        console.log('confirmcap',confirmcap);
        if (dataresult !== confirmcap) {
            setcaperror("Please Enter Valid Captcha")
        }
        else {
            setcaptcha("");
            const referancenumber = ref;
            Axios.get(`http://localhost:8000/trackparcel/${referancenumber}`)
                .then((res) => {
                    if (res.status === 200) {
                        Setshow("show");
                        setparcel({
                            parceldata: res.data.parceldata,
                            destinationdata: res.data.destinationdata,
                            staffparceldata: res.data.staffparceldata
                        })
                        if (res.data.staffparceldata.branchparcelstatus == "Delivered") {
                            setparcelstatus("Delivered");
                        }
                        else if (res.data.staffparceldata.parcelstatus == "Received") {
                            setparcelstatus("Ready For Delivere");
                        }
                        else if (res.data.destinationdata.parcelstatus == "Received") {
                            setparcelstatus("Pickedup By Destiny Branch");
                        }
                        else if (res.data.parceldata.branchparcelstatus == "Dispatch") {
                            setparcelstatus("In-Transit");
                        }
                        else if (res.data.parceldata.parcelstatus == "Collected") {
                            setparcelstatus("Collected");
                        }
                        else {
                            setparcelstatus("Data Not Available");
                        }


                    }
                    else if (res.status === 400) {
                        console.log("hi");
                        Setshow(" ");
                    }
                    else {
                        console.log("Error");
                    }
                })
        }
    }

    return (
        <div className={isActive ? "g-sidenav-show " : "g-sidenav-show  g-sidenav-pinned"}>
            {/* <Dashboard /> */}
            <main className="main-content position-relative  border-radius-lg trackmain">
                {/* <div className="tracklogo">
                    <img src={mainlogo1} alt="" className='tracpulogo' />
                </div> */}
                {/* <div className="row">
                    <div className="col-md-12 mx-auto">
                        <div className="tracuserktxt mx-auto">
                            <h3 className='tracktitle'> <span className='usertxtspan'>KNZ</span> Courier Service</h3>
                        </div>
                    </div>
                </div> */}
                <div className="container srccon1 mt-6">
                    <h3>Track Your Parcel</h3>
                    <div className="search">
                        <input type="text" placeholder='Enter Referance Number..' value={ref} onChange={(e) => Setref(e.target.value)} />
                        <i className="fa fa-search" aria-hidden="true"></i>
                        <button className='btn mt-3 srhbtn' onClick={setcap}  >Next</button>
                        <div>
                            {
                                captcha === "captcha" ? (
                                    <>
                                    <div className='capspan'>
                                        <p>{dataresult}</p>
                                        <input type="text" placeholder='Enter Captcha' id='capinput' value={confirmcap} onChange={(e) => setconfirmcap(e.target.value)} autoComplete="off"/>
                                        <button className='btn mt-3 capbtn' onClick={handlesearch} >Search</button>
                                    </div>
                                    
                                    
                                    <span style={{color:"red"}}>{caperror}</span>
                                    </>

                                ) : " "
                            }
                        </div>
                    </div>
                </div>

                {show === "show" ?


                    <div className="container-fluid mt-5 trackmain">
                        <div className="row usertrack1">
                            <div className="col-md-12 mr-auto">
                                <h5>Tracking Details</h5>
                            </div>
                        </div>



                        <div className="row  mainbox mt-3">
                            <div className="col-md-3 bo1">
                                <h5>Estimated Delivery time:</h5>
                                {moment(parcel.parceldata.createdAt).add(7, 'days').format('LL')}
                            </div>
                            <div className="col-md-3 bo2">
                                <h5>Shipping BY:</h5>
                                {parcel.parceldata.branchprocessed}
                            </div>
                            <div className="col-md-3 bo3">
                                <h5>Status:</h5>
                                {parcelstatus}

                            </div>
                            <div className="col-md-3 bo4">
                                <h5>Tracking Number:</h5>
                                {parcel.parceldata.referancenumber}
                            </div>
                        </div>

                        <div className="row mt-5 usertrack2">
                            <div className="track">
                                <div className={parcelstatus === "Collected" || parcelstatus === "In-Transit" || parcelstatus === "Pickedup By Destiny Branch" || parcelstatus === "Ready For Delivere" || parcelstatus === "Delivered" ? "step active" : "step "}> <span className="icon"> <i className="fa fa-check"></i> </span> <span className="text">Order Collected</span> </div>
                                <div className={parcelstatus === "In-Transit" || parcelstatus === "Pickedup By Destiny Branch" || parcelstatus === "Ready For Delivere" || parcelstatus === "Delivered" ? "step active" : "step "}> <span className="icon"> <i className="fa fa-truck"></i> </span> <span className="text"> In-Transit</span> </div>
                                <div className={parcelstatus === "Pickedup By Destiny Branch" || parcelstatus === "Ready For Delivere" || parcelstatus === "Delivered" ? "step active" : "step "} > <span className="icon"> <i className="fa fa-box"></i> </span> <span className="text"> Pickedup By <span style={{ color: "rgb(55, 129, 226)", fontWeight: "bold" }}>{parcel.parceldata.pickupbranch}</span> Branch </span> </div>
                                <div className={parcelstatus === "Ready For Delivere" || parcelstatus === "Delivered" ? "step active" : "step "}> <span className="icon"> <i className="fa fa-user"></i> </span> <span className="text">Ready For Delivere</span> </div>
                                <div className={parcelstatus === "Delivered" ? "step active" : "step "}> <span className="icon"> <i className="fa fa-home"></i> </span> <span className="text">Delivered</span> </div>
                            </div>
                        </div>
                    </div>
                    : " "}

            </main>
        </div>
    )
};
export default Usertrackparcel;