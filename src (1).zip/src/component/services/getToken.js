export const getToken = localStorage.getItem("token");
export const getstaffToken = localStorage.getItem("stafftoken");
